#!/bin/sh

"${abs_top_builddir:-.}/src/test/test" --fraction 6/8
