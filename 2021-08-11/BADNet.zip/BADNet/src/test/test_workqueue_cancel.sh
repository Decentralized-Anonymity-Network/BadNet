#!/bin/sh

"${builddir:-.}/src/test/test_workqueue" -C 1

